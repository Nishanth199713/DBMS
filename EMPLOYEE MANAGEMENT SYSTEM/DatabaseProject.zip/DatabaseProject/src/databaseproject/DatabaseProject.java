package databaseproject;

        import java.io.BufferedReader;
        import java.io.FileReader;
        import java.io.IOException;
        import java.sql.Connection;
        import java.sql.DriverManager;
        import java.sql.PreparedStatement;
        import java.sql.SQLException;

public class DatabaseProject {

    public static void main(String[] args) {
        String URL = "jdbc:mysql://acadmysqldb001p.uta.edu:3306/nxs7727";
        String user = "nxs7727";
        String pass = "Beatsbydre@1997";
        String csv= "C:\\Users\\NISHANTH\\Downloads\\projects\\projects\\project1_soccer_worldcup\\DB1_Project1\\DatabaseProject\\src\\databaseproject\\Emp.csv";
        String csv1 = "C:\\Users\\NISHANTH\\Downloads\\projects\\projects\\project1_soccer_worldcup\\DB1_Project1\\DatabaseProject\\src\\databaseproject\\Dept.csv";
        String csv2 = "C:\\Users\\NISHANTH\\Downloads\\projects\\projects\\project1_soccer_worldcup\\DB1_Project1\\DatabaseProject\\src\\databaseproject\\Dept_Loc.csv";
        String csv3 = "C:\\Users\\NISHANTH\\Downloads\\projects\\projects\\project1_soccer_worldcup\\DB1_Project1\\DatabaseProject\\src\\databaseproject\\Project.csv";
        String csv4 = "C:\\Users\\NISHANTH\\Downloads\\projects\\projects\\project1_soccer_worldcup\\DB1_Project1\\DatabaseProject\\src\\databaseproject\\Works_on.csv";
        String csv5 = "C:\\Users\\NISHANTH\\Downloads\\projects\\projects\\project1_soccer_worldcup\\DB1_Project1\\DatabaseProject\\src\\databaseproject\\Dependent.csv";

        //int batchSize = 20;

        Connection conn = null;


        try {

            conn = DriverManager.getConnection(URL, user, pass);
            conn.setAutoCommit(false);

            String sql1 = "insert into EMPLOYEE values(?,?,?,?,?,?,?,?,?,?);";
            PreparedStatement statement = conn.prepareStatement(sql1);

            BufferedReader line = new BufferedReader(new FileReader(csv));
            String lineT = null;

            //int count = 0;

            //lineReader.readLine(); // skip header line

            while ((lineT = line.readLine()) != null) {
                String[] data = lineT.split(",");
                statement.setString(1, data[0]);
                statement.setString(2, data[1]);
                statement.setString(3, data[2]);
                statement.setString(4, data[3]);
                statement.setString(5, data[4]);
                statement.setString(6, data[5]);
                statement.setString(7, data[6]);
                statement.setString(8, data[7]);
                statement.setString(9, data[8]);
                statement.setString(10, data[9]);

                statement.executeUpdate();
            }
            String sql2 = "insert into  DEPARTMENT values(?,?,?,?);";
            PreparedStatement statement1 = conn.prepareStatement(sql2);

            BufferedReader line1 = new BufferedReader(new FileReader(csv1));
            String lineT1 = null;

            //int count = 0;

            //lineReader.readLine(); // skip header line

            while ((lineT1 = line1.readLine()) != null) {
                String[] data = lineT1.split(",");
                statement1.setString(1, data[0]);
                statement1.setString(2, data[1]);
                statement1.setString(3, data[2]);
                statement1.setString(4, data[3]);
                statement1.executeUpdate();
            }

            String sql3 = "insert into DEPT_LOCATIONS values(?,?);";
            PreparedStatement statement2 = conn.prepareStatement(sql3);

            BufferedReader line2 = new BufferedReader(new FileReader(csv2));
            String lineT2 = null;

            //int count = 0;

            //lineReader.readLine(); // skip header line

            while ((lineT2 = line2.readLine()) != null) {
                String[] data = lineT2.split(",");
                statement2.setString(1, data[0]);
                statement2.setString(2, data[1]);

                statement2.executeUpdate();
            }

            String sql4 = "insert into PROJECT values(?,?,?,?);";
            PreparedStatement statement3 = conn.prepareStatement(sql4);

            BufferedReader line3 = new BufferedReader(new FileReader(csv3));
            String lineT3= null;

            //int count = 0;

            //lineReader.readLine(); // skip header line

            while ((lineT3 = line3.readLine()) != null) {
                String[] data = lineT3.split(",");
                statement3.setString(1, data[0]);
                statement3.setString(2, data[1]);
                statement3.setString(3, data[2]);
                statement3.setString(4, data[3]);

                statement3.executeUpdate();
            }

            String sql5 = "insert into WORKS_ON (Essn,Pno,Hours)values(?,?,?);";
            PreparedStatement statement4 = conn.prepareStatement(sql5);
            BufferedReader line4 = new BufferedReader(new FileReader(csv4));
            String lineT4 = null;

                //int count = 0;

            //lineReader.readLine(); // skip header line
            while((lineT4=line4.readLine())!= null) {
                String[] data = lineT4.split(",");
                statement4.setString(1, data[0]);
                statement4.setString(2, data[1]);
                statement4.setString(3, data[2]);
                statement4.executeUpdate();
            }
            String sql6 = "insert into DEPENDENT values(?,?,?,?,?);";
            PreparedStatement statement5 = conn.prepareStatement(sql6);

            BufferedReader line5 = new BufferedReader(new FileReader(csv5));
            String lineT5 = null;

            //int count = 0;

            //lineReader.readLine(); // skip header line

            while ((lineT5 = line5.readLine()) != null) {
                String[] data = lineT5.split(",");
                statement5.setString(1, data[0]);
                statement5.setString(2, data[1]);
                statement5.setString(3, data[2]);
                statement5.setString(4, data[3]);
                statement5.setString(5, data[4]);


                statement5.executeUpdate();
            }



            line.close();
            line1.close();
            line2.close();
            line3.close();
             line4.close();
             line5.close();

            // execute the remaining queries


            conn.commit();
            conn.close();

        } catch (IOException ex) {
            System.err.println(ex);
        } catch (SQLException ex) {
            ex.printStackTrace();

            try {
                conn.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

    }

}